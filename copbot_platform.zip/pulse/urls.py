# pulse folderinin içində urls.py faylı yaradın
from django.urls import path

app_name = 'pulse'
urlpatterns = [
    # Hələlik boşdur, sonra əlavə edəcəyik
]